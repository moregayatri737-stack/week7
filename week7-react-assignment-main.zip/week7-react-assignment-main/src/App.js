import React, { Suspense, useMemo } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ReactQueryDevtools } from "@tanstack/react-query-devtools";
import { ThemeProvider, createTheme, CssBaseline } from "@mui/material";
import { useSelector } from "react-redux";
import Navbar from "./components/Navbar";

// Lazy loaded pages (Task 4 requirement)
const Dashboard = React.lazy(() => import("./pages/Dashboard"));
const About = React.lazy(() => import("./pages/About"));

const queryClient = new QueryClient();

function App() {
  // get theme mode from redux
  const mode = useSelector((state) => state.theme.mode);

  // create theme dynamically
  const theme = useMemo(
    () =>
      createTheme({
        palette: {
          mode: mode,
        },
      }),
    [mode]
  );

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <Navbar />

        <Suspense fallback={<div>Loading...</div>}>
          <Dashboard />
          {/* Second lazy loaded page for PDF compliance */}
          <About />
        </Suspense>

        <ReactQueryDevtools initialIsOpen={false} />
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
