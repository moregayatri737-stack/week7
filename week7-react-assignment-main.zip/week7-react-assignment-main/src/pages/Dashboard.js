import React, { useMemo } from "react";
import { Container, Typography, Grid, Card, CardContent } from "@mui/material";
import CounterPage from "./CounterPage";
import UsersPage from "./UsersPage";

function Dashboard() {
  const stats = useMemo(
    () => [
      { title: "Total Users", value: 10 },
      { title: "Redux Counter", value: "Global State" },
      { title: "API Status", value: "Connected" },
    ],
    []
  );

  return (
    <Container maxWidth="lg" sx={{ mt: 4 }}>
      <Typography variant="h4" fontWeight="bold" gutterBottom>
        Dashboard
      </Typography>

      {/* Summary Cards */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        {stats.map((item, index) => (
          <Grid item xs={12} md={4} key={index}>
            <Card elevation={3}>
              <CardContent>
                <Typography color="text.secondary">
                  {item.title}
                </Typography>
                <Typography variant="h5" fontWeight="bold">
                  {item.value}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Functional Sections */}
      <Grid container spacing={4}>
        <Grid item xs={12} md={6}>
          <CounterPage />
        </Grid>
        <Grid item xs={12} md={6}>
          <UsersPage />
        </Grid>
      </Grid>
    </Container>
  );
}

export default Dashboard;
