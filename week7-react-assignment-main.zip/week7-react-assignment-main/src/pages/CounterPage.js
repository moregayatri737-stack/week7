import React, { useCallback } from "react";
import { useSelector, useDispatch } from "react-redux";
import { increment, decrement, reset } from "../store/counterSlice";
import { Card, CardContent, Typography, Button, Stack } from "@mui/material";

function CounterPage() {
  const count = useSelector((state) => state.counter.value);
  const dispatch = useDispatch();

  const inc = useCallback(() => dispatch(increment()), [dispatch]);

  return (
    <Card elevation={3}>
      <CardContent>
        <Typography variant="h6" gutterBottom>
          Redux Counter
        </Typography>

        <Typography variant="h4" fontWeight="bold" sx={{ mb: 2 }}>
          {count}
        </Typography>

        <Stack direction="row" spacing={2}>
          <Button variant="contained" onClick={inc}>
            Add
          </Button>
          <Button variant="outlined" onClick={() => dispatch(decrement())}>
            Update
          </Button>
          <Button color="error" onClick={() => dispatch(reset())}>
            Reset
          </Button>
        </Stack>
      </CardContent>
    </Card>
  );
}

export default React.memo(CounterPage);
