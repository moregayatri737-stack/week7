import React, { useState, useMemo } from "react";
import {
  Card,
  CardContent,
  Typography,
  TextField,
  List,
  ListItem,
  ListItemText,
  Button,
  Stack,
  Pagination,
} from "@mui/material";
import {
  useQuery,
  useMutation,
  useQueryClient,
} from "@tanstack/react-query";

const indianUsers = [
  { name: "Amit Sharma", email: "amit.sharma@gmail.com" },
  { name: "Rahul Patil", email: "rahul.patil@gmail.com" },
  { name: "Sneha Deshmukh", email: "sneha.deshmukh@gmail.com" },
  { name: "Pooja Kulkarni", email: "pooja.kulkarni@gmail.com" },
  { name: "Rohit Verma", email: "rohit.verma@gmail.com" },
  { name: "Neha Joshi", email: "neha.joshi@gmail.com" },
  { name: "Sanket More", email: "sanket.more@gmail.com" },
  { name: "Priya Pawar", email: "priya.pawar@gmail.com" },
  { name: "Akash Jadhav", email: "akash.jadhav@gmail.com" },
  { name: "Anjali Chavan", email: "anjali.chavan@gmail.com" },
];

const USERS_PER_PAGE = 5;

function UsersPage() {
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);

  const queryClient = useQueryClient();

  // GET users
  const {
    data = [],
    isLoading,
    isError,
  } = useQuery({
    queryKey: ["users"],
    queryFn: () =>
      fetch("https://jsonplaceholder.typicode.com/users").then((res) =>
        res.json()
      ),
  });

  // POST user
  const addUserMutation = useMutation({
    mutationFn: (newUser) =>
      fetch("https://jsonplaceholder.typicode.com/users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newUser),
      }).then((res) => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries(["users"]);
    },
  });

  // Transform API data
  const transformedData = useMemo(
    () =>
      data.map((u, index) => ({
        id: u.id,
        name: indianUsers[index]?.name || u.name,
        email: indianUsers[index]?.email || u.email,
      })),
    [data]
  );

  // Search filter
  const filtered = useMemo(
    () =>
      transformedData.filter((u) =>
        u.name.toLowerCase().includes(search.toLowerCase())
      ),
    [transformedData, search]
  );

  // Pagination logic
  const totalPages = Math.ceil(filtered.length / USERS_PER_PAGE);

  const paginatedUsers = useMemo(() => {
    const start = (page - 1) * USERS_PER_PAGE;
    return filtered.slice(start, start + USERS_PER_PAGE);
  }, [filtered, page]);

  return (
    <Card elevation={3}>
      <CardContent>
        <Typography variant="h6" gutterBottom>
          Users (React Query + Pagination)
        </Typography>

        <Stack direction="row" spacing={2} sx={{ mb: 2 }}>
          <TextField
            fullWidth
            size="small"
            label="Search user"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1); // reset page on search
            }}
          />

          <Button
            variant="contained"
            onClick={() =>
              addUserMutation.mutate({
                name: "New User",
                email: "newuser@gmail.com",
              })
            }
          >
            Add
          </Button>
        </Stack>

        {isLoading && <Typography>Loading users...</Typography>}

        {isError && (
          <Typography color="error">
            Error while fetching users
          </Typography>
        )}

        {!isLoading && !isError && (
          <>
            <List>
              {paginatedUsers.map((u) => (
                <ListItem key={u.id} divider>
                  <ListItemText primary={u.name} secondary={u.email} />
                </ListItem>
              ))}
            </List>

            {/* Pagination UI */}
            <Stack alignItems="center" mt={2}>
              <Pagination
                count={totalPages}
                page={page}
                onChange={(e, value) => setPage(value)}
                color="primary"
              />
            </Stack>
          </>
        )}
      </CardContent>
    </Card>
  );
}

export default React.memo(UsersPage);
