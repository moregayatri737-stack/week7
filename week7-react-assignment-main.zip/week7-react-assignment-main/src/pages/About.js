import React from "react";
import { Container, Typography } from "@mui/material";

function About() {
  return (
    <Container sx={{ mt: 4 }}>
      <Typography variant="h4" gutterBottom>
        About Application
      </Typography>
      <Typography>
        This dashboard demonstrates Redux Toolkit, React Query,
        Material UI, and React performance optimization techniques.
      </Typography>
    </Container>
  );
}

export default React.memo(About);
