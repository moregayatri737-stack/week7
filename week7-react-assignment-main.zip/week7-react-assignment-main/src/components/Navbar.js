import React from "react";
import { AppBar, Toolbar, Button, Typography } from "@mui/material";
import { useDispatch } from "react-redux";
import { toggleTheme } from "../store/themeSlice";

function Navbar() {
  const dispatch = useDispatch();

  return (
    <AppBar position="static">
      <Toolbar>
        <Typography variant="h6" sx={{ flexGrow: 1 }}>
          Week 7 Assignment
        </Typography>

        <Button color="inherit" onClick={() => dispatch(toggleTheme())}>
          Toggle Dark / Light Mode
        </Button>
      </Toolbar>
    </AppBar>
  );
}

export default React.memo(Navbar);
